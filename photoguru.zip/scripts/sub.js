$(function(){
	$('.pix_diapo').diapo();
});

$(function(){
	$( "pix_diapo" ).on( "swiperight", nextSlide );
});

$(function(){
	$( "pix_diapo" ).on( "swipeleft", prevSlide );
});



window.addEventListener("resize", resize);
function resize(){
//location.href="index.html";
}

function home(){
xpage="index.html?rpt=1";
location.href=xpage;
}
