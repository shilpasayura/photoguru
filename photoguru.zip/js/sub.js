
window.addEventListener("resize", resize);
function resize(){
//location.href="index.html";
}

function getpage(xpage){
xpage=xpage+".html";
location.href=xpage;
}


function home(){
xpage="index.html?rpt=1";
location.href=xpage;
}
